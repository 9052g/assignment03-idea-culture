export default function Home() {
  return <iframe title="Idea Culture" src="/experience/index.html" style={{position:'fixed',inset:0,width:'100%',height:'100%',border:0,background:'#090d0b'}} />;
}
