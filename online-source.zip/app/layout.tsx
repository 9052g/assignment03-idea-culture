import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Idea Culture · 念头培养皿",
  description: "Plant ideas and watch unexpected connections grow.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
